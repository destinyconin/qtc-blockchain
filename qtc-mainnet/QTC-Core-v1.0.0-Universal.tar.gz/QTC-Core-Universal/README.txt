QTC Core v1.0.0 - Universal Package
====================================

FOR WINDOWS USERS:
- Double-click: QTC.bat
- Or run: INSTALL_WINDOWS.bat (for installation)

FOR LINUX/MAC USERS:
- Run: ./qtc_linux
- Make executable first: chmod +x qtc_linux

IMPORTANT:
- Backup wallet.dat - contains your private keys!
- Default port: 8333

Support: https://github.com/destinyconin/qtc-core
