QTC Miner v2.0 - Final Edition
===============================

FILES:
- QTC_MINER_FINAL.bat - Main mining program
- START.bat - Quick launcher
- wallet.dat - Your wallet (auto-created)

HOW TO USE:
1. Double-click START.bat to begin
2. Select [1] to start mining
3. Watch for "BLOCK FOUND" messages
4. Your balance increases automatically

IMPORTANT:
- Backup wallet.dat - contains your private key!
- Mining shows real-time progress
- Blocks found are shown clearly
- Balance updates automatically

Support: https://github.com/destinyconin/qtc-core
